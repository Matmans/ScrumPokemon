import {Type} from "./type.model";

export class Types {
    constructor (
        public slot: number,
        public type: Type
    ) {}
}