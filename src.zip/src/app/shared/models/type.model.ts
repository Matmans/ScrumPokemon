export class Type {
    constructor ( 
        public name: string
    ) {}
}